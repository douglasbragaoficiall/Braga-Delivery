<?php
 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>
<script type="text/template" id="myd-template-product-item-extra-name">
    <div class="myd-cart__products-extra-item">`{extraItemName}`</div>
</script>