<?php
 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>
<script type="text/template" id="myd-template-product-item-extra">
    <div class="myd-cart__products-extra">
        <div class="myd-cart__products-extra-title">`{extraType}`</div>
        `{extraName}`
    </div>
</script>